---------------------------------------
FOR PERSONAL USE ONLY!
---------------------------------------

This DEMO version was created for TESTING purposes only. It contains only the basic alphabet without lowercase letters, only basic punctuation and a partial set of numbers as well as partial kerning.

Please DO NOT use this font in any public way, meaning selling or publishing anything that involves the use of this font.

If you like to use the full, multilingual version without the glyph limitation and for commercial purposes, you can find information on where to buy it here: www.typerookie.de

Thanks very much for your support! :)