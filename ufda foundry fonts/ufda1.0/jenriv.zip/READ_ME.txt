This font is 100% FREE for personal use and commercial use.

NO REDISTRIBUTION in any case.

===

This font is Titling version, which contains all-caps letters.

It also supports extended Latin languages, advanced symbols.

For lowercase, small caps and Opentype features, please purchase full version. More info at: https://linh-n.com/

===

Any donation will be greatly appreciated.

Thanks.